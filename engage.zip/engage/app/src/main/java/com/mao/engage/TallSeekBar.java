package com.mao.engage;

import android.content.Context;
import android.util.AttributeSet;

/**
 * TODO: document your custom view class.
 */
public class TallSeekBar extends androidx.appcompat.widget.AppCompatSeekBar {
    public TallSeekBar(Context context) {
        super(context);
    }

    public TallSeekBar(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public TallSeekBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }


}
